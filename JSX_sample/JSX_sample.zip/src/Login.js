import React, { Component } from 'react';
import './Login.css';

class Login extends Component {
  render() {
    return (
      // JSX 문법으로 변환 적용해주세요.
      <div></div>
    );
  }
}

export default Login;
